from Crypto.PublicKey import RSA

def generar_clave_cliente():
    clave_cliente = RSA.generate(2048)
    clave_publica_cliente = clave_cliente.publickey().export_key()

    with open("clave_publica_cliente.pem", "wb") as pub_file:
        pub_file.write(clave_publica_cliente)

    with open("clave_privada_cliente.pem", "wb") as priv_file:
        priv_file.write(clave_cliente.export_key())

if __name__ == "__main__":
    generar_clave_cliente()
    print("Clave pública del cliente generada y guardada como 'clave_publica_cliente.pem'.")
